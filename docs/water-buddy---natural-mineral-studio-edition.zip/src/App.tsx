import React, { useState, useEffect } from 'react';
import { ActiveTab, ProformaData } from './types';
import { Navigation } from './components/Navigation';
import { LandingView } from './components/LandingView';
import { ArchitectureView } from './components/ArchitectureView';
import { PricingView } from './components/PricingView';
import { ContactView } from './components/ContactView';
import { DesignSystemView } from './components/DesignSystemView';
import { ProformaModal, CheckoutModal, DownloadModal } from './components/Modals';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('landing');
  const [currentIntake, setCurrentIntake] = useState<number>(() => {
    const saved = localStorage.getItem('wb_intake');
    return saved ? parseInt(saved, 10) : 1850;
  });
  const [dailyGoal, setDailyGoal] = useState<number>(() => {
    const saved = localStorage.getItem('wb_goal');
    return saved ? parseInt(saved, 10) : 2800;
  });

  // Modal states
  const [proformaData, setProformaData] = useState<ProformaData | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [downloadOpen, setDownloadOpen] = useState(false);

  // Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('wb_intake', currentIntake.toString());
  }, [currentIntake]);

  useEffect(() => {
    localStorage.setItem('wb_goal', dailyGoal.toString());
  }, [dailyGoal]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage(null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogWater = (amount: number, label: string) => {
    setCurrentIntake((prev) => {
      const next = prev + amount;
      return next;
    });
    showToast(`+${amount}ml ${label} recorded. Total is now ${(currentIntake + amount).toLocaleString()} ml.`);
  };

  const handleResetIntake = () => {
    setCurrentIntake(0);
    showToast('Daily intake counter reset to 0 ml.');
  };

  const handleUpdateGoal = (newGoal: number) => {
    setDailyGoal(newGoal);
    showToast(`Daily target calibrated to ${newGoal.toLocaleString()} ml.`);
  };

  return (
    <div className="min-h-screen bg-[#070f19] text-[#dbe3f3] flex flex-col justify-between selection:bg-[#38bdf8]/20 selection:text-[#38bdf8] film-grain relative">
      {/* Top Floating Header Capsule */}
      <Navigation
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onDownloadClick={() => setDownloadOpen(true)}
      />

      {/* Main Content Router */}
      <main className="grow pt-24 sm:pt-28 px-4 sm:px-6 md:px-8 max-w-6xl mx-auto w-full transition-opacity duration-300">
        {activeTab === 'landing' && (
          <LandingView
            currentIntake={currentIntake}
            dailyGoal={dailyGoal}
            onLogWater={handleLogWater}
            onResetIntake={handleResetIntake}
            onUpdateGoal={handleUpdateGoal}
            onNavigateTab={handleTabChange}
            onTriggerDownload={() => setDownloadOpen(true)}
            onTriggerCheckout={() => setCheckoutOpen(true)}
            onToast={showToast}
          />
        )}

        {activeTab === 'architecture' && (
          <ArchitectureView
            onTriggerDownload={() => setDownloadOpen(true)}
            onTriggerCheckout={() => setCheckoutOpen(true)}
            onToast={showToast}
          />
        )}

        {activeTab === 'pricing' && (
          <PricingView
            onTriggerDownload={() => setDownloadOpen(true)}
            onTriggerCheckout={() => setCheckoutOpen(true)}
            onOpenProformaModal={(data) => setProformaData(data)}
            onToast={showToast}
          />
        )}

        {activeTab === 'contact' && <ContactView onToast={showToast} />}

        {activeTab === 'design-system' && <DesignSystemView onToast={showToast} />}
      </main>

      {/* Global Modals */}
      <ProformaModal
        data={proformaData}
        onClose={() => setProformaData(null)}
        onToast={showToast}
      />

      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        onToast={showToast}
      />

      <DownloadModal
        isOpen={downloadOpen}
        onClose={() => setDownloadOpen(false)}
        onToast={showToast}
      />

      {/* Toast Notification HUD */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 transform transition-all duration-300 frosted-pill px-5 py-3 rounded-2xl border border-[#38bdf8]/30 text-xs shadow-2xl flex items-center gap-3 animate-bounce">
          <span className="w-2 h-2 rounded-full bg-[#38bdf8] shadow-[0_0_8px_#38bdf8]"></span>
          <span className="text-white font-medium">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
