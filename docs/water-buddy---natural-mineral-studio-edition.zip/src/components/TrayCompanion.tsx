import React, { useState, useEffect } from 'react';
import { playBasaltDrop } from '../utils/audio';
import { RotateCcw, Plus, Sparkles, Check } from 'lucide-react';

interface TrayCompanionProps {
  currentIntake: number;
  dailyGoal: number;
  onLogWater: (amount: number, label: string) => void;
  onReset?: () => void;
  onUpdateGoal?: (goal: number) => void;
}

export const TrayCompanion: React.FC<TrayCompanionProps> = ({
  currentIntake,
  dailyGoal,
  onLogWater,
  onReset,
  onUpdateGoal,
}) => {
  const [timeString, setTimeString] = useState('');
  const [minutesRemaining, setMinutesRemaining] = useState(24);
  const [secondsRemaining, setSecondsRemaining] = useState(0);
  const [showCustomModal, setShowCustomModal] = useState(false);
  const [customVal, setCustomVal] = useState('200');
  const [editingGoal, setEditingGoal] = useState(false);
  const [goalInput, setGoalInput] = useState(String(dailyGoal));

  // Live clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeString(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Interval timer countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining((prevSec) => {
        if (prevSec > 0) return prevSec - 1;
        setMinutesRemaining((prevMin) => (prevMin > 0 ? prevMin - 1 : 45));
        return 59;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleQuickLog = (amount: number, label: string) => {
    playBasaltDrop();
    onLogWater(amount, label);
    // Reset interval timer to 45 mins upon hydration
    setMinutesRemaining(45);
    setSecondsRemaining(0);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(customVal, 10);
    if (!isNaN(parsed) && parsed > 0) {
      handleQuickLog(parsed, 'Custom');
      setShowCustomModal(false);
    }
  };

  const percentage = Math.min(100, Math.round((currentIntake / dailyGoal) * 100));
  const strokeDashoffset = 276 - (276 * percentage) / 100;

  return (
    <div className="w-full max-w-md frosted-glass rounded-2xl p-6 shadow-[0_20px_50px_rgba(0,0,0,0.6)] border border-white/10 relative animate-drift">
      {/* Window Tray Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-white/5">
        <div className="flex items-center gap-2.5">
          <span className="w-2.5 h-2.5 rounded-full bg-[#38bdf8] shadow-[0_0_8px_#38bdf8] animate-pulse"></span>
          <span className="font-mono text-xs text-slate-300 tracking-wider uppercase font-medium">
            Tray Companion
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span>{timeString || '02:40 PM'}</span>
          <span className="text-slate-600">•</span>
          <span className="text-slate-400">WIN32</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-1"></span>
        </div>
      </div>

      {/* Central Minimalist Metric Indicator */}
      <div className="py-7 flex flex-col items-center justify-center text-center">
        <div className="relative w-44 h-44 rounded-full border border-white/5 flex flex-col items-center justify-center p-4 my-2">
          {/* Restrained Water Fill Arc Indicator */}
          <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              fill="transparent"
              r="44"
              stroke="rgba(255,255,255,0.05)"
              strokeWidth="3.5"
            />
            <circle
              cx="50"
              cy="50"
              fill="transparent"
              r="44"
              stroke="url(#trayMineralGradient)"
              strokeDasharray="276"
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              strokeWidth="4"
              className="transition-all duration-700 ease-out"
            />
            <defs>
              <linearGradient id="trayMineralGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#8ed5ff" />
              </linearGradient>
            </defs>
          </svg>

          <span className="text-[11px] font-mono uppercase tracking-widest text-slate-400 mb-1">
            Today's Total
          </span>
          <span className="font-display text-4xl font-normal text-white tracking-tight tabular-nums">
            {currentIntake.toLocaleString()}
          </span>

          {editingGoal ? (
            <div className="flex items-center gap-1 mt-1 z-10">
              <input
                type="number"
                value={goalInput}
                onChange={(e) => setGoalInput(e.target.value)}
                className="w-16 px-1 py-0.5 bg-black/60 border border-[#38bdf8]/40 rounded text-center text-xs font-mono text-white"
                autoFocus
              />
              <button
                onClick={() => {
                  const num = parseInt(goalInput, 10);
                  if (num > 500 && onUpdateGoal) onUpdateGoal(num);
                  setEditingGoal(false);
                }}
                className="p-1 text-emerald-400 hover:text-white"
              >
                <Check className="w-3 h-3" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                setGoalInput(String(dailyGoal));
                setEditingGoal(true);
              }}
              title="Click to calibrate daily goal"
              className="text-xs font-mono text-slate-400 mt-0.5 hover:text-[#38bdf8] transition-colors flex items-center gap-1 group"
            >
              <span>/ {dailyGoal.toLocaleString()} ml</span>
              <span className="text-[10px] text-slate-500 opacity-0 group-hover:opacity-100">✎</span>
            </button>
          )}

          <span className="text-[10px] font-mono text-[#38bdf8]/90 mt-1">
            {percentage}% completed
          </span>
        </div>

        {/* Pacing Interval Status */}
        <div className="mt-3 flex items-center gap-2 text-xs font-sans text-slate-300">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#38bdf8] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#38bdf8]"></span>
          </span>
          <span>
            Next interval in{' '}
            <strong className="text-white font-mono font-medium">
              {minutesRemaining}m {secondsRemaining < 10 ? `0${secondsRemaining}` : secondsRemaining}s
            </strong>
          </span>
        </div>
      </div>

      {/* Quick Sip Micro-Triggers */}
      <div className="grid grid-cols-4 gap-2 pt-2 border-t border-white/5">
        <button
          onClick={() => handleQuickLog(150, 'Sip')}
          className="py-2.5 px-2 rounded-lg bg-white/[0.03] hover:bg-[#38bdf8]/15 hover:border-[#38bdf8]/30 active:scale-95 transition-all text-center group border border-white/5 focus:outline-none"
        >
          <div className="font-mono text-xs text-white group-hover:text-[#38bdf8] transition-colors font-medium">
            +150 ml
          </div>
          <div className="text-[10px] text-slate-400 font-sans mt-0.5">Sip</div>
        </button>

        <button
          onClick={() => handleQuickLog(250, 'Glass')}
          className="py-2.5 px-2 rounded-lg bg-white/[0.03] hover:bg-[#38bdf8]/15 hover:border-[#38bdf8]/30 active:scale-95 transition-all text-center group border border-white/5 focus:outline-none"
        >
          <div className="font-mono text-xs text-white group-hover:text-[#38bdf8] transition-colors font-medium">
            +250 ml
          </div>
          <div className="text-[10px] text-slate-400 font-sans mt-0.5">Glass</div>
        </button>

        <button
          onClick={() => handleQuickLog(500, 'Flask')}
          className="py-2.5 px-2 rounded-lg bg-white/[0.03] hover:bg-[#38bdf8]/15 hover:border-[#38bdf8]/30 active:scale-95 transition-all text-center group border border-white/5 focus:outline-none"
        >
          <div className="font-mono text-xs text-white group-hover:text-[#38bdf8] transition-colors font-medium">
            +500 ml
          </div>
          <div className="text-[10px] text-slate-400 font-sans mt-0.5">Flask</div>
        </button>

        <button
          onClick={() => setShowCustomModal(true)}
          className="py-2.5 px-2 rounded-lg bg-white/[0.03] hover:bg-white/[0.08] active:scale-95 transition-all text-center group border border-white/5 focus:outline-none flex flex-col items-center justify-center"
          title="Log custom amount"
        >
          <Plus className="w-3.5 h-3.5 text-slate-400 group-hover:text-white" />
          <div className="text-[10px] text-slate-400 font-sans mt-0.5">Custom</div>
        </button>
      </div>

      {/* Footnote Status & Reset */}
      <div className="mt-4 flex items-center justify-between text-[11px] font-mono text-slate-500 pt-2 border-t border-white/5">
        <span className="flex items-center gap-1.5">
          <span>Google Cloud Telemetry</span>
          <span className="text-emerald-400">• Synced (14ms)</span>
        </span>
        {onReset && (
          <button
            onClick={() => {
              if (window.confirm('Reset current daily intake ledger to 0 ml?')) {
                onReset();
              }
            }}
            title="Reset daily count"
            className="text-slate-500 hover:text-slate-300 transition-colors p-1"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Custom Amount Modal */}
      {showCustomModal && (
        <div className="absolute inset-0 bg-[#070f19]/95 backdrop-blur-md rounded-2xl p-6 flex flex-col justify-center items-center z-20 border border-white/10">
          <form onSubmit={handleCustomSubmit} className="w-full space-y-4 text-center">
            <h4 className="text-sm font-semibold text-white">Log Custom Intake</h4>
            <div className="flex items-center justify-center gap-2">
              <input
                type="number"
                min="10"
                max="2000"
                step="25"
                value={customVal}
                onChange={(e) => setCustomVal(e.target.value)}
                autoFocus
                className="w-28 text-center text-lg font-mono px-3 py-1.5 rounded-lg bg-white/5 border border-white/20 text-white focus:outline-none focus:border-[#38bdf8]"
              />
              <span className="text-sm font-mono text-slate-400">ml</span>
            </div>
            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => setShowCustomModal(false)}
                className="px-3 py-1.5 rounded-lg bg-white/5 text-slate-400 text-xs hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-[#38bdf8] text-[#070f19] font-semibold text-xs hover:bg-white"
              >
                Log Intake
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
